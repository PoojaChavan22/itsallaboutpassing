package com.student.dao;

public interface QueryMapper {
	
	public static final String viewAll= "select studentroll,name,dob from student_tbl";

}
