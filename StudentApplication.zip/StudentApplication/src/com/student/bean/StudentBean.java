package com.student.bean;

import java.time.LocalDate;
import java.util.Date;



public class StudentBean {
	
	
	private int studentId;
	private String name;
	private LocalDate studentDob;
	
	public StudentBean() {
		super();
	}

	public StudentBean(int studentId, String name, LocalDate studentDob) {
		super();
		this.studentId = studentId;
		this.name = name;
		this.studentDob = studentDob;
	}

	public int getStudentId() {
		return studentId;
	}

	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LocalDate getStudentDob() {
		return studentDob;
	}

	public void setStudentDob(LocalDate studentDob) {
		this.studentDob = studentDob;
	}

	@Override
	public String toString() {
		return "StudentBean [studentId=" + studentId + ", name=" + name
				+ ", studentDob=" + studentDob + "]";
	}
	
	
	
	
	
}
